@extends('main.main')
@section('content')
 <!-- Carousel -->
 <section class="carousel-area">
    <div class="navbar">
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="{{asset('asset/image/pabrik.png')}}" alt="Gambar"></div>
        </div>
    </div>
</section>

@endsection
