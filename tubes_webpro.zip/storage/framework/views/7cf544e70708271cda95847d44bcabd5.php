<!DOCTYPE html>

<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default" data-assets-path="../assets/"
    data-template="vertical-menu-template-free">

<head>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title><?php echo $__env->yieldContent('title'); ?> - EchoPulse</title>

    <meta name="description" content="" />
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />


    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('asset/admin/img/favicon/favicon.ico')); ?>" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet" />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="<?php echo e(asset('asset/admin/fonts/boxicons.css')); ?>" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('asset/admin/css/core.css')); ?>" class="template-customizer-core-css" />
    
    <link rel="stylesheet" href="<?php echo e(asset('asset/admin/css/theme-default.css')); ?>"
        class="template-customizer-theme-css" />
    
    <link rel="stylesheet" href="<?php echo e(asset('asset/admin/css/demo.css')); ?>" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('asset/admin/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('asset/admin/libs/apex-charts/apex-charts.css')); ?>" />

    <!-- DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <!-- DataTables Responsive CSS -->
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">

    <!-- Page CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/color-calendar/dist/css/theme-basic.css" />


    <!-- Helpers -->
    <script src="<?php echo e(asset('asset/admin/js/helpers.js')); ?>"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="<?php echo e(asset('asset/admin/js/config.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->
            <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- / Menu -->
            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->
                <?php echo $__env->make('admin.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- / Navbar -->
                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <!-- / Content -->
                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?php echo e(asset('asset/admin/libs/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/admin/libs/popper/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/admin/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/admin/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>

    <script src="<?php echo e(asset('asset/admin/js/menu.js')); ?>"></script>
    <!-- endbuild -->
    <script src="<?php echo e(asset('asset/admin/libs/apex-charts/apexcharts.js')); ?>"></script>

    <!-- Main JS -->
    <script src="<?php echo e(asset('asset/admin/js/main.js')); ?>"></script>

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <!-- DataTables Responsive JS -->
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script>
        window.Laravel = <?php echo json_encode([
            'asset_url' => asset('')
        ]); ?>;
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/admin/dashboard.js']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(["resources/js/pages/admin/sidebar/sidebar.js"]); ?>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
</body>

</html>
<?php /**PATH C:\Users\LOQ\Documents\Sekolah\Semester 5\Perancangan dan pemograman web\tubes\tubes_webpro\resources\views/admin/layout/master.blade.php ENDPATH**/ ?>