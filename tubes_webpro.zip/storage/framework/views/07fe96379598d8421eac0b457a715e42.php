<?php $__env->startSection('title', 'Forum'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container ">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">FORMULIR /</span> Data Forum</h4>

        <div class="card">
            <div class=" text-nowrap p-3">
                <div class=" alert-dismissible fade show" id="alert" role="alert"></div>
                <table class="table" id="table-forum">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>author</th>
                            <th>title</th>
                            
                            <th>Content</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/admin/forum/index.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

<style>
    .dataTables_wrapper .dataTables_paginate .paginate_button.current,
    .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
        color: #fff !important;
        background: #264417 !important;
        border-color: #264417 !important;
    }

</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LOQ\Documents\Sekolah\Semester 5\Perancangan dan pemograman web\tubes\tubes_webpro\resources\views/admin/pages/forum/index.blade.php ENDPATH**/ ?>