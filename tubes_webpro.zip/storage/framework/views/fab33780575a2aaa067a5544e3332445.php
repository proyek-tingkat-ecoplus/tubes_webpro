<?php $__env->startSection('title', 'Proposal'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container ">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">PROPOSAL /</span> Data Forum</h4>

        <div class="card">
            <div class=" text-nowrap p-3">
                <table class="table" id="table-proposal">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>name</th>
                            <th>deskription</th>
                            <th>file</th>
                            <th>start_date</th>
                            <th>end_date</th>
                            <th>status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

<style>
    .dataTables_wrapper .dataTables_paginate .paginate_button.current,
    .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
        color: #fff !important;
        background: #264417 !important;
        border-color: #264417 !important;
    }

</style>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/user/proposal_user.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LOQ\Documents\Sekolah\Semester 5\Perancangan dan pemograman web\tubes\tubes_webpro\resources\views/admin/pages/proposal/index.blade.php ENDPATH**/ ?>