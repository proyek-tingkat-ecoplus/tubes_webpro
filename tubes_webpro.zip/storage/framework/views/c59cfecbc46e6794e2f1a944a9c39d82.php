<?php $__env->startSection('content'); ?>
<img src="<?php echo e(asset('asset/image/pabrik.jpeg')); ?>" class="img-fluid img-hero" alt="Responsive image">
<div class="form">
    <section class="pos">
        <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="tambah diskusi baru" aria-label="tambah diskusi baru" aria-describedby="button-addon2">
            <a class="btn search-bar" type="button" id="button-addon2" href="/tambahpesan">
                <i class="fa-solid fa-plus"></i>
            </a>
        </div>
        <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post-item rounded-3">
            <h3 class="d-blok mb-3" style="color: white">Infastruktur terbaru</h3>
            <div class="d-flex">
                <div class="profile">
                    <div class="profile rounded-circle"> <img src="<?php echo e(asset('asset/image/icon-data.png')); ?>" alt=""></div>
                </div>
                <div class="content">
                    <p class="nama"><?php echo e($forum->name); ?></p>
                    <p class="jam-pengisian"><?php echo e($forum->created_at->diffForHumans()); ?></p>
                    <p class="isi"><span> Infrastruktur terbaru </span> <br>  <?php echo e($forum->description); ?></p>
                </div>
            </div>
        </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LOQ\Documents\Sekolah\Semester 5\Perancangan dan pemograman web\tubes\tubes_webpro\resources\views/form.blade.php ENDPATH**/ ?>